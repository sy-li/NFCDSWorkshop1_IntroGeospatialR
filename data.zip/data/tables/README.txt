AGB: Aboveground biomass (unit:MgC/ha)
MAR: Mean annual rainfall (unit:mm)
MAT: Mean annual temperature (unit:�C)

MAR and MAR are modified from Climatic Research Unit data.
AGB is modified from Avitabile et al 2016.
